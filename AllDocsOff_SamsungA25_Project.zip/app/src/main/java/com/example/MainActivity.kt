package com.example

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DocumentFormat
import com.example.model.DocumentMetadata
import com.example.ui.DocumentUiState
import com.example.ui.DocumentViewModel
import com.example.ui.dialogs.ByteIntegrityDialog
import com.example.ui.dialogs.FormatPickerDialog
import com.example.ui.dialogs.PreFlightDialog
import com.example.ui.docx.DocxInspector
import com.example.ui.editor.TextEditor
import com.example.ui.home.DocumentHomeScreen
import com.example.ui.pdf.PdfViewer
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: DocumentViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize sample documents
        viewModel.loadSamples(this)

        setContent {
            val uiState by viewModel.uiState.collectAsState()
            MyApplicationTheme(amoledMode = uiState.isAmoledBlackMode) {
                DocPreserveApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocPreserveApp(viewModel: DocumentViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var showMoreMenu by remember { mutableStateOf(false) }
    var pendingTargetFormat by remember { mutableStateOf<DocumentFormat?>(null) }

    // SAF Open Document launcher
    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.openDocument(context, uri)
        }
    }

    // SAF Save / Export Document launcher
    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("*/*")
    ) { uri: Uri? ->
        val targetFormat = pendingTargetFormat
        if (uri != null && targetFormat != null) {
            viewModel.executeSave(context, uri, targetFormat)
        }
        pendingTargetFormat = null
    }

    // Show status messages in snackbar
    LaunchedEffect(uiState.statusMessage) {
        val msg = uiState.statusMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
        }
    }

    val showOuterTopBar = uiState.metadata == null || uiState.metadata?.format == DocumentFormat.PDF

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            if (showOuterTopBar) {
                DocPreserveTopAppBar(
                    metadata = uiState.metadata,
                    isAmoledMode = uiState.isAmoledBlackMode,
                    onToggleAmoled = { viewModel.toggleAmoledMode() },
                    onBack = { viewModel.closeDocument() },
                    onSave = {
                        val meta = uiState.metadata
                        if (meta != null) {
                            if (meta.uri.scheme == "memory") {
                                // Needs target URI from user
                                pendingTargetFormat = meta.format
                                createDocumentLauncher.launch(meta.name)
                            } else {
                                // Direct save to current file (No-Op byte copy if !isDirty)
                                viewModel.executeSave(context, meta.uri, meta.format)
                            }
                        }
                    },
                    onSaveAs = {
                        viewModel.setFormatPickerVisible(true)
                    },
                    onShowIntegrity = {
                        viewModel.setIntegrityDialogVisible(true)
                    },
                    onShowKnoxVault = {
                        viewModel.setKnoxVaultDialogVisible(true)
                    },
                    onPrint = {
                        viewModel.printCurrentDocument(context)
                    },
                    onMoreMenuToggle = { showMoreMenu = !showMoreMenu },
                    showMoreMenu = showMoreMenu,
                    onDismissMoreMenu = { showMoreMenu = false }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (showOuterTopBar) innerPadding else androidx.compose.foundation.layout.PaddingValues(0.dp))
        ) {
            val meta = uiState.metadata
            val bytes = uiState.rawBytes

            if (meta == null || bytes == null) {
                // Home Screen with test documents and quick actions
                DocumentHomeScreen(
                    sampleDocs = uiState.sampleDocs,
                    onOpenSaf = {
                        openDocumentLauncher.launch(
                            arrayOf(
                                "application/pdf",
                                "text/plain",
                                "text/markdown",
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                "*/*"
                            )
                        )
                    },
                    onCreateNew = { format ->
                        viewModel.createNewDocument(format)
                    },
                    onOpenSample = { sample ->
                        viewModel.openDocument(context, sample.uri, sample.name)
                    }
                )
            } else {
                // Active Document Workspace
                when (meta.format) {
                    DocumentFormat.PDF -> {
                        PdfViewer(
                            fileBytes = bytes,
                            onPageRotationChanged = { viewModel.onPageRotated() },
                            onShowInfo = { viewModel.setIntegrityDialogVisible(true) }
                        )
                    }

                    DocumentFormat.TXT, DocumentFormat.MD, DocumentFormat.DOCX, DocumentFormat.ODT -> {
                        com.example.ui.word.WordDocumentEditor(
                            metadata = meta,
                            initialContent = uiState.textContent,
                            onContentChanged = { viewModel.onTextChanged(it) },
                            onSave = {
                                if (meta.uri.scheme == "memory") {
                                    pendingTargetFormat = meta.format
                                    createDocumentLauncher.launch(meta.name)
                                } else {
                                    viewModel.executeSave(context, meta.uri, meta.format)
                                }
                            },
                            onSaveAs = {
                                viewModel.setFormatPickerVisible(true)
                            },
                            onClose = {
                                viewModel.closeDocument()
                            },
                            onPrint = {
                                viewModel.printCurrentDocument(context)
                            },
                            onShowIntegrity = {
                                viewModel.setIntegrityDialogVisible(true)
                            },
                            onShowKnoxVault = {
                                viewModel.setKnoxVaultDialogVisible(true)
                            },
                            onToggleAmoled = {
                                viewModel.toggleAmoledMode()
                            },
                            isAmoledMode = uiState.isAmoledBlackMode
                        )
                    }

                    DocumentFormat.UNKNOWN -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Binärformat nicht direkt editierbar.\nByte-Preserving No-Op-Save bleibt aktiv.",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Saving progress overlay
            AnimatedVisibility(
                visible = uiState.isSaving,
                modifier = Modifier.align(Alignment.Center)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shadowElevation = 8.dp
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Validiere & Sichere...",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }

    // Pre-Flight Lossy Warning Modal
    val report = uiState.preFlightReport
    if (report != null) {
        PreFlightDialog(
            report = report,
            features = uiState.features,
            onConfirm = {
                val target = report.toFormat
                pendingTargetFormat = target
                val currentName = uiState.metadata?.name ?: "dokument"
                val baseName = currentName.substringBeforeLast(".")
                createDocumentLauncher.launch("$baseName.${target.extension}")
            },
            onDismiss = {
                viewModel.dismissPreFlight()
            }
        )
    }

    // Format Selector Modal ("Speichern unter...")
    if (uiState.showFormatPicker) {
        val currentFormat = uiState.metadata?.format ?: DocumentFormat.TXT
        FormatPickerDialog(
            currentFormat = currentFormat,
            onFormatSelected = { selectedFormat ->
                viewModel.setFormatPickerVisible(false)
                viewModel.requestSaveOrPreFlight(selectedFormat)
            },
            onDismiss = {
                viewModel.setFormatPickerVisible(false)
            }
        )
    }

    // Byte-Integrity Inspector Modal
    if (uiState.showIntegrityDialog && uiState.metadata != null) {
        ByteIntegrityDialog(
            metadata = uiState.metadata!!,
            features = uiState.features,
            currentSha256 = uiState.metadata!!.currentSha256,
            onDismiss = {
                viewModel.setIntegrityDialogVisible(false)
            }
        )
    }

    // Samsung Knox Hardware-Vault Dialog
    if (uiState.showKnoxVaultDialog && uiState.metadata != null && uiState.rawBytes != null) {
        com.example.ui.dialogs.KnoxVaultDialog(
            fileName = uiState.metadata!!.name,
            rawBytes = uiState.rawBytes!!,
            onEncryptDocument = { viewModel.encryptCurrentDocumentWithKnox() },
            onDecryptDocument = { viewModel.decryptCurrentDocumentWithKnox() },
            onDismiss = { viewModel.setKnoxVaultDialogVisible(false) }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocPreserveTopAppBar(
    metadata: DocumentMetadata?,
    isAmoledMode: Boolean,
    onToggleAmoled: () -> Unit,
    onBack: () -> Unit,
    onSave: () -> Unit,
    onSaveAs: () -> Unit,
    onShowIntegrity: () -> Unit,
    onShowKnoxVault: () -> Unit,
    onPrint: () -> Unit,
    onMoreMenuToggle: () -> Unit,
    showMoreMenu: Boolean,
    onDismissMoreMenu: () -> Unit
) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = if (isAmoledMode) androidx.compose.ui.graphics.Color.Black else com.example.ui.theme.WordBlue,
            titleContentColor = androidx.compose.ui.graphics.Color.White,
            navigationIconContentColor = androidx.compose.ui.graphics.Color.White,
            actionIconContentColor = androidx.compose.ui.graphics.Color.White
        ),
        title = {
            if (metadata != null) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = metadata.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = androidx.compose.ui.graphics.Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        // Dirty indicator or clean check
                        if (metadata.isDirty) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(androidx.compose.ui.graphics.Color.Yellow, CircleShape)
                            )
                        } else {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_shield_check),
                                contentDescription = "Byte-Identisch",
                                tint = androidx.compose.ui.graphics.Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                    Text(
                        text = if (!metadata.isDirty)
                            "${metadata.format.displayName} · No-Op-Save bereit"
                        else
                            "${metadata.format.displayName} · Geändert (isDirty = true)",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 11.sp,
                        color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f)
                    )
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.25f),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "W",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = androidx.compose.ui.graphics.Color.White
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Word",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = androidx.compose.ui.graphics.Color.White
                    )
                }
            }
        },
        navigationIcon = {
            if (metadata != null) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("btn_close_doc")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Dokument schließen"
                    )
                }
            }
        },
        actions = {
            // Super-AMOLED True-Black Quick Toggle
            IconButton(
                onClick = onToggleAmoled,
                modifier = Modifier.testTag("btn_toggle_amoled")
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isAmoledMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    border = if (isAmoledMode) null else androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Text(
                        text = if (isAmoledMode) "AMOLED ✓" else "AMOLED",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isAmoledMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            if (metadata != null) {
                // Direct Save (No-op byte copy if not dirty)
                IconButton(
                    onClick = onSave,
                    modifier = Modifier.testTag("btn_save_document")
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_save),
                        contentDescription = "Speichern (Byte-Preserving No-Op)",
                        tint = if (!metadata.isDirty) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary
                    )
                }

                // Integrity & feature analysis
                IconButton(
                    onClick = onShowIntegrity,
                    modifier = Modifier.testTag("btn_show_integrity")
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_shield_check),
                        contentDescription = "Byte-Integritätsanalyse",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Overflow menu
                Box {
                    IconButton(
                        onClick = onMoreMenuToggle,
                        modifier = Modifier.testTag("btn_more_options")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Weitere Optionen"
                        )
                    }

                    DropdownMenu(
                        expanded = showMoreMenu,
                        onDismissRequest = onDismissMoreMenu
                    ) {
                        DropdownMenuItem(
                            text = { Text("Speichern unter... (Pre-Flight)") },
                            onClick = {
                                onDismissMoreMenu()
                                onSaveAs()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Byte-Integrität & Hashes") },
                            onClick = {
                                onDismissMoreMenu()
                                onShowIntegrity()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Samsung Knox Hardware-Tresor 🔒") },
                            onClick = {
                                onDismissMoreMenu()
                                onShowKnoxVault()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Über Android drucken / PDF-Spooler 🖨️") },
                            onClick = {
                                onDismissMoreMenu()
                                onPrint()
                            }
                        )
                    }
                }
            }
        }
    )
}
